# realworld-nuxtjs
一个nuxtjs案例