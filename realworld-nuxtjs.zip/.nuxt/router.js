import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _432e5379 = () => interopDefault(import('../pages/layout' /* webpackChunkName: "" */))
const _0067d624 = () => interopDefault(import('../pages/home' /* webpackChunkName: "" */))
const _0c225d8c = () => interopDefault(import('../pages/login' /* webpackChunkName: "" */))
const _12a63b3a = () => interopDefault(import('../pages/profile' /* webpackChunkName: "" */))
const _593d869c = () => interopDefault(import('../pages/settings' /* webpackChunkName: "" */))
const _375f79bc = () => interopDefault(import('../pages/editor' /* webpackChunkName: "" */))
const _0d1f02f2 = () => interopDefault(import('../pages/article' /* webpackChunkName: "" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/",
    component: _432e5379,
    children: [{
      path: "",
      component: _0067d624,
      name: "home"
    }, {
      path: "/login",
      component: _0c225d8c,
      name: "login"
    }, {
      path: "/register",
      component: _0c225d8c,
      name: "register"
    }, {
      path: "/profile/:username",
      component: _12a63b3a,
      name: "profile"
    }, {
      path: "/settings",
      component: _593d869c,
      name: "settings"
    }, {
      path: "/editor/:slug?",
      component: _375f79bc,
      name: "editor"
    }, {
      path: "/article/:slug",
      component: _0d1f02f2,
      name: "article"
    }]
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config.app && config.app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
